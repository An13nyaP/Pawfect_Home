
import { findMEle, wishList } from "./wishList.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getDatabase, ref, set, get, child } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";

const firebaseConfig = {
    apiKey: "AIzaSyCKR8lXVOKiRNDOz5jq5BAyj_h9gfeSbTM",
    authDomain: "pawfect-home.firebaseapp.com",
    projectId: "pawfect-home",
    storageBucket: "pawfect-home.appspot.com",
    messagingSenderId: "483821780893",
    appId: "1:483821780893:web:c14212091a3cc615fe3974",
    measurementId: "G-2147LXPH74"

};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const db = getDatabase(app);

let appli = JSON.parse(localStorage.getItem('appli')) || ' ';
let germanshepherd = JSON.parse(localStorage.getItem('germanshepherd'));
let lab = JSON.parse(localStorage.getItem('lab'));
let pomeranian = JSON.parse(localStorage.getItem('pomeranian'));
let Husky = JSON.parse(localStorage.getItem('Husky'));
let poodle = JSON.parse(localStorage.getItem('poodle'));
let goldenDoodle = JSON.parse(localStorage.getItem('goldenDoodle'));

let dog = findMEle(appli);
let id = document.querySelector('#dogId');
let name = document.querySelector('#dogName');
if (appli == ' ') {
    id.value = ' ';
    name.value = ' ';
}
else {
    id.value = `${dog.id}`;
    name.value = `${dog.name}`;
}


let sub = document.querySelector('#submitBtn');
sub.addEventListener('click', (e) => {
    let flag = 0;
    goldenDoodle.forEach((doodle, i) => {
        if (doodle.id == document.querySelector('#dogId').value && doodle.name == document.querySelector('#dogName').value) {
            flag = 1;
            goldenDoodle.splice(i, 1);
            localStorage.setItem('goldenDoodle', JSON.stringify(goldenDoodle));
        }
    })
    pomeranian.forEach((pomeranian, i) => {
        if (pomeranian.id == document.querySelector('#dogId').value && pomeranian.name == document.querySelector('#dogName').value) {
            flag = 1;
            pomeranian.splice(i, 1);
            localStorage.setItem('pomeranian', JSON.stringify(pomeranian));
        }
    })

    lab.forEach((l, i) => {
        if (l.id == document.querySelector('#dogId').value && l.name == document.querySelector('#dogName').value) {
            flag = 1;
            lab.splice(i, 1);
            console.log(lab);
            localStorage.setItem('lab', JSON.stringify(lab));
        }
    })
    Husky.forEach((Hus, i) => {
        if (Hus.id == document.querySelector('#dogId').value && Hus.name == document.querySelector('#dogName').value) {
            flag = 1;
            Husky.splice(i, 1);
            localStorage.setItem('Husky', JSON.stringify(Husky));
        }
    })
    poodle.forEach((poo, i) => {
        if (poo.id == document.querySelector('#dogId').value && poo.name == document.querySelector('#dogName').value) {
            flag = 1;
            poodle.splice(i, 1);
            localStorage.setItem('poodle', JSON.stringify(poodle));
        }
    })
    germanshepherd.forEach((gmsp, i) => {
        if (gmsp.id == document.querySelector('#dogId').value && gmsp.name == document.querySelector('#dogName').value) {
            flag = 1;
            germanshepherd.splice(i, 1);
            localStorage.setItem('germanshepherd', JSON.stringify(germanshepherd));
        }
    })
    if (document.getElementById('fullName').value == '' && document.getElementById('email').value == '' && document.getElementById('phone').value == '' && document.getElementById('address').value == '' && document.getElementById('livingSituation').value == '') {
        alert("Fill all the data!");
    }
    else if (flag === 1) {
        wishList.forEach((wishL, ind) => {
            if (wishL == document.querySelector('#dogId').value) {
                wishList.splice(ind, 1);
                localStorage.setItem('list', JSON.stringify(wishList));
            }
        })
        localStorage.removeItem('appli');
        e.preventDefault();
        const fullName = document.getElementById("fullName").value;
        const email = document.getElementById("email").value;
        const phone = document.getElementById("phone").value;
        const address = document.getElementById("address").value;
        const dogName = document.getElementById("dogName").value;
        const dogId = document.getElementById("dogId").value;
        const livingSituation = document.getElementById("livingSituation").value;
        set(ref(db, 'Applications/' + fullName), {
            fullName: fullName,
            email: email,
            phone: phone,
            address: address,
            dogName: dogName,
            dogId: dogId,
            livingSituation: livingSituation
        }).then(() => {
            alert("Application submitted successfully!");
            window.location.href = `http://127.0.0.1:5500/DOGS/Dogs.html`;
        }).catch((error) => {
            console.error("Failed to submit application:", error);
            alert("Failed to submit application: " + error.message);
        });
    } else {
        alert("Invalid Id or name, check again!");
    }
})



