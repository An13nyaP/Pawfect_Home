

let ele =  document.querySelectorAll('.adopt'); // Adjust the selector as needed
let appli = '';
ele.forEach((btn)=>{
    btn.addEventListener('click' , ()=>{
        appli = btn.id;
        localStorage.setItem('appli',JSON.stringify(appli));
        window.location.href = `http://127.0.0.1:5500/DOGS/application.html`;
    })
})


